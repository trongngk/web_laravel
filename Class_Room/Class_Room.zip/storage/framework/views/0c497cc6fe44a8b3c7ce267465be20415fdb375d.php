<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  
  <?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body class="clickup-chrome-ext_installed">

    <div class="wrapper ">
      <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main-panel">
        <!-- Navbar -->
        <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    
                      <?php echo csrf_field(); ?>
                      <h4 class="card-title ">Hint</h4>
                      

                      
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <form action="<?php echo e(route("challenge.hint", $challenge->id)); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-success btn-link">Show hint</button>
                      </form>
                      <div class="dropdown-divider"></div>
                      <form action="<?php echo e(route("challenge.submit", $challenge->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        
                        <input class="form-control" type="text" name="answer" placeholder="<?php echo e(__('Answer...')); ?>"
                          required>

                        <br>
                        <button class="btn btn-success btn-link">Submit</button>

                      </form>

                    </div>

                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>




      </div>
    </div>
    <!--   Core JS Files   -->
    
  </body>
</html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/challenge/detail.blade.php ENDPATH**/ ?>