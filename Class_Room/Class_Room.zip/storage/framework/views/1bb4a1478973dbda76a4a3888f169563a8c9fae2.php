<head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <!-- Extra details for Live View on GitHub Pages -->
      <!-- Canonical SEO -->
      

      <title><?php echo e(__('Class Room')); ?></title>
      <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('/img/apple-icon.png')); ?>">
      <link rel="icon" type="image/png" href="<?php echo e(asset('/img/favicon.png')); ?>">
      <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
      <!--     Fonts and icons     -->
      <link rel="stylesheet" type="text/css"
        href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
      <!-- CSS Files -->
      <link href="<?php echo e(asset('/css/material-dashboard.css?v=2.1.3')); ?>" rel="stylesheet" />
      <!-- CSS Just for demo purpose, don't include it in your project -->
      
      <!-- Google Tag Manager -->
      <script>(function (w, d, s, l, i) {
          w[l] = w[l] || []; w[l].push({
            'gtm.start':
              new Date().getTime(), event: 'gtm.js'
          }); var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
              'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-NKDMSK6');</script>
      <!-- End Google Tag Manager -->

    </head><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/layouts/navbars/head.blade.php ENDPATH**/ ?>