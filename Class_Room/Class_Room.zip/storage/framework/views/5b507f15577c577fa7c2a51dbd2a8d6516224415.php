

<!DOCTYPE html>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
      <?php echo $__env->make('layouts.navbars.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <body class="clickup-chrome-ext_installed">
        
        <div class="wrapper ">
          <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="main-panel">
            <!-- Navbar -->
            <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                      <form action="<?php echo e(route('challenge.store')); ?>" enctype="multipart/form-data" method="post">

                      <?php echo csrf_field(); ?>
                      <div class="card ">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title"><?php echo e(__('Create challenge')); ?></h4>
                          
                        </div>
                        <div class="card-body ">
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Challenge name')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="text" name="name" placeholder="<?php echo e(__('Challenge name')); ?>" required>                             
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Hint')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="text" name="hint" placeholder="<?php echo e(__('Hint')); ?>" required>                             
                              </div>
                            </div>
                          </div>            
                          <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('File ')); ?></label>
                        <div class="col-sm-7">
                          <div>
                            <input class="form-control" type="file" name="file" placeholder="<?php echo e(__('File')); ?>" required>
                          </div>
                        </div>
                      </div>
                        <div class="card-footer ml-auto mr-auto">
                          <button type="submit" class="btn btn-primary"><?php echo e(__('Add')); ?></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
          <!--   Core JS Files   -->
        <?php echo $__env->make('layouts.navbars.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </body>
    </html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/challenge/create.blade.php ENDPATH**/ ?>