<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  
  <?php echo $__env->make('layouts.app_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body class="clickup-chrome-ext_installed">

    <div class="wrapper ">
      <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="main-panel">
        <!-- Navbar -->
        <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <form action="<?php echo e(route('data.store')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="card ">
                    <div class="card-header card-header-primary">
                      <h4 class="card-title"><?php echo e(__('Add User')); ?></h4>
                      <p class="card-category"><?php echo e(__('User information')); ?></p>
                    </div>
                    <div class="card-body ">
                      <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('User name')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group">
                            <input class="form-control" type="text" name="username" placeholder="<?php echo e(__('Name')); ?>"
                              required>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Fullname')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group">
                            <input class="form-control" type="text" name="fullname" placeholder="<?php echo e(__('Full name')); ?>"
                              required>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Password')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group">
                            <input class="form-control" type="password" name="password"
                              placeholder="<?php echo e(__('Password')); ?>" required>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group">
                            <input class="form-control" type="email" name="email" placeholder="<?php echo e(__('Email')); ?>"
                              required>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Phone Number')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group">
                            <input class="form-control" type="text" name="phone" placeholder="<?php echo e(__('Phone number')); ?>"
                              required>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Role')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group">
                          <input type="radio" name="role" value="1">Teacher
                          <input type="radio" name="role" value="0">Student
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="card-footer ml-auto mr-auto">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Add')); ?></button>
                  </div>
              </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </div>
    </div>
    <!--   Core JS Files   -->
    

  </body>
</html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/data/create.blade.php ENDPATH**/ ?>