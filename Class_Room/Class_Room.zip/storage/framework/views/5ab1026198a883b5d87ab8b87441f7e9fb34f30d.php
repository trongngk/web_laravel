
  <!DOCTYPE html>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
      <?php echo $__env->make('layouts.navbars.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <body class="clickup-chrome-ext_installed">
        
        <div class="wrapper ">
          <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="main-panel">
            <!-- Navbar -->
            <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <?php if(session()->get("level") === 1): ?>
                      <form action="<?php echo e(route('data.Teacherupdate',$data->id)); ?>" method="post">
                    <?php else: ?>
                      <form action="<?php echo e(route('data.Studentupdate',$data->id)); ?>" method="post">
                    <?php endif; ?>
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('put'); ?>

                      <div class="card ">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title"><?php echo e(__('Edit Profile')); ?></h4>
                          <p class="card-category"><?php echo e(__('User information')); ?></p>
                        </div>
                        <div class="card-body ">                    
                          <?php if(session()->get("level") === 1): ?>
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('User name')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="text" name="username" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($data->username); ?>" required>                             
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Fullname')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="text" name="fullname" placeholder="<?php echo e(__('Full name')); ?>" value="<?php echo e($data->fullname); ?>" required>                             
                              </div>
                            </div>
                          </div>             
                          <?php endif; ?>             
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Password')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="password" name="password" placeholder="<?php echo e(__('Password')); ?>" value="<?php echo e($data->password); ?>" required>                             
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="email" name="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e($data->email); ?>" required>                             
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Phone Number')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input class="form-control" type="text" name="phone" placeholder="<?php echo e(__('Phone number')); ?>" value="<?php echo e($data->phone); ?>" required>                             
                              </div>
                            </div>
                          </div>
                          
                        <?php if(session()->get("level") === 1): ?>
                        <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Role')); ?></label>
                            <div class="col-sm-7">
                              <div class="form-group">
                                <input type="radio" name="role" value="1">Teacher                             
                                <input type="radio" name="role" value="0">Student                      
                              </div>
                            </div>
                          </div>
                        </div>
                        <?php endif; ?>
                        <div class="card-footer ml-auto mr-auto">
                          <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
          <!--   Core JS Files   -->
        <?php echo $__env->make('layouts.navbars.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </body>
    </html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/data/edit.blade.php ENDPATH**/ ?>