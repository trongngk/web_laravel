<!DOCTYPE html>
<html>
    <head>
        <title>Class</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">       
    </head>
    <body>
    <h1>Assignment [ <?php echo e($assignment->description); ?>]</h1>
    <br>
    <p >File: <?php echo e($assignment->filename); ?>&emsp; Due to: <?php echo e(($assignment->deadline)); ?></p>
    <br>
    Turn in
    <input type="file" name="submitfile" placeholder="Choose file" id="file">
    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br>
    <div>
        <button type="submit" id="submit">
            Turn in
        </button>
    </div>
   
    </body>
</html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/assignments/detail.blade.php ENDPATH**/ ?>