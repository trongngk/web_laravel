<!DOCTYPE html>
  <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <?php echo $__env->make('layouts.navbars.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body class="clickup-chrome-ext_installed">

      <div class="wrapper ">
        <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-panel">
          <!-- Navbar -->
          <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="content">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header card-header-primary">
            <form action="<?php echo e(route('assignmentSubmit.store', $assignment->id)); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <h4 class="card-title ">Assignments [ <?php echo e($assignment->description); ?>]</h4>                      
        <p class="card-category">File: <a href="<?php echo e(route('assignments.downloadFile', $assignment->filename)); ?>"><?php echo e($assignment->filename); ?></a> &emsp; Due to: <?php echo e($assignment->deadline); ?></p>                      
        <br>
        Turn in
        <input type="file" name="file" placeholder="Choose file">
        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <div>
            <button type="submit">
                Turn in
            </button>
        </div>
    </form>
    </div>
    <div class="card-body">                        
        <div class="table-responsive">
            <table class="table">
                <thead class=" text-primary">
                    <tr>
                        <th>Time submit</th>
                        <th>File</th>
                        <th>Student</th>
                        <th>#</th>
                    </tr>
                    <?php $__currentLoopData = $assignmentSubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignmentSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <td><?php echo e($assignmentSub->created_at); ?></td> 
                        <td><a href="<?php echo e(route('assignments.downloadFile', $assignmentSub->filename)); ?>"><?php echo e($assignmentSub->filename); ?></a></td>
                        <td><?php echo e($assignmentSub->studentSubmit); ?></td> 
                        <td>
                            <form action="<?php echo e(route('assignments.destroySub', $assignmentSub->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                                                  <button class="btn btn-success btn-link"><i class="material-icons">delete</i></button>  

                        </td>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
            </table>
        </div>
    </div>
        
    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>




 </div>
      </div>
      <!--   Core JS Files   -->
      <?php echo $__env->make('layouts.navbars.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
  </html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/assignments/student_detail.blade.php ENDPATH**/ ?>