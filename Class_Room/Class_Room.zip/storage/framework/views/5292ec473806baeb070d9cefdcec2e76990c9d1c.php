<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  
  <?php echo $__env->make('layouts.app_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body class="clickup-chrome-ext_installed">
    <div class="wrapper ">
      <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main-panel">
        <!-- Navbar -->
        <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title ">Receive Message</h4>
                  </div>
                  <div class="card-body">
                    <div class="row">
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class=" text-primary">
                          <tr>
                            <th>
                              Time
                            </th>
                            <th>
                              Content
                            </th>
                            <th>
                              From
                            </th>
                            <th class="text-right">
                              #
                            </th>
                          </tr>
                        </thead>
                        <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($message->created_at); ?></td>
                          <td><?php echo e($message->Content); ?></td>
                          <td><?php echo e($message->userSent); ?></td>
                          <td class="td-actions text-right">
                            <form action="<?php echo e(route('message.detail', $message->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="mess" value=<?php echo e($message->userSent); ?>>
                              <button class="btn btn-success btn-link"><i class="material-icons">details</i></button>
                            </form>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <!--   Core JS Files   -->
    
  </body>
</html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/message/index.blade.php ENDPATH**/ ?>