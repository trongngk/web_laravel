<<!DOCTYPE html>
  <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    
    <?php echo $__env->make('layouts.app_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <body class="clickup-chrome-ext_installed">

      <div class="wrapper ">
        <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-panel">
          <!-- Navbar -->
          <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="content">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header card-header-primary">
                      <h4 class="card-title ">Assignments</h4>
                      
                    </div>
                    <div class="card-body">
                      <div class="row">
                        <?php if(session()->get("level") === 1): ?>
                        <div class="col-12 text-right">
                          <a href="<?php echo e(route('assignments.create')); ?>" class="btn btn-sm btn-primary">New challenge</a>
                        </div>
                        <?php endif; ?>
                      </div>
                      <div class="table-responsive">
                        <table class="table">
                          <thead class=" text-primary">
                            <tr>
                              <th>Due to</th>
                              <th>Description</th>
                              <th class="text-center">#</th>
                            </tr>
                            <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tbody>
                            <td><?php echo e($assignment->deadline); ?></td>
                            <td><?php echo e($assignment->description); ?></td>
                            <td>
                              <?php if(session()->get('level') === 1): ?>
                              <form action="<?php echo e(route('assignments.Teacherdetail')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="assign" value=<?php echo e($assignment->id); ?>>
                                <button class="btn btn-success btn-link"><i class="material-icons">details</i></button>
                              </form>
                              <form action="<?php echo e(route('assignments.destroy', $assignment->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-success btn-link"><i class="material-icons">delete</i></button>
                              </form>
                              <?php else: ?>
                              <form action="<?php echo e(route('assignments.Studentdetail', $assignment->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="assign" value=<?php echo e($assignment->id); ?>>
                                <button class="btn btn-success btn-link"><i class="material-icons">details</i></button>

                              </form>
                              <?php endif; ?>
                            </td>
                          </tbody>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </thead>
                        </table>
                      </div>

                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>




        </div>
      </div>
      <!--   Core JS Files   -->
      
    </body>
  </html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/assignments/index.blade.php ENDPATH**/ ?>