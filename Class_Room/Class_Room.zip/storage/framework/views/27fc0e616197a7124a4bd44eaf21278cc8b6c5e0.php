<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <body class="clickup-chrome-ext_installed">

    <div class="wrapper ">
      <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main-panel">
        <!-- Navbar -->
        <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title ">Answer</h4>
                    
                  </div>
                  <div class="card-body">
                    <iframe src="http://localhost/Class_Room/public/assets/<?php echo e($challenge->file); ?>"
                      style="background-color: Snow;" width="100%" height="500" style="border:1px solid black"></iframe>

                  </div>
                </div>
              </div>




            </div>
          </div>
          <!--   Core JS Files   -->
          
  </body>
</html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/challenge/answer.blade.php ENDPATH**/ ?>