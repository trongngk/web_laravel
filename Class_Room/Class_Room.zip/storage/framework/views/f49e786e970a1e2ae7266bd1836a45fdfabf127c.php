<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  
  <?php echo $__env->make('layouts.app_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body class="clickup-chrome-ext_installed">

    <div class="wrapper ">
      <?php echo $__env->make("layouts.navbars.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main-panel">
        <!-- Navbar -->
        <?php echo $__env->make('layouts.navbars.navs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title ">Challenge</h4>
                    
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <?php if(session()->get("level") === 1): ?>

                      <div class="col-12 text-right">
                        <a href="<?php echo e(route('challenge.create')); ?>" class="btn btn-sm btn-primary">New</a>
                      </div>
                      <?php endif; ?>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class=" text-primary">
                            <tr>
                              <th>Challenge name</th>
                              <th class="text-center">#</th>
                            </tr>
                        </thead>

                        <?php $__currentLoopData = $challenge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>

                          <td><?php echo e($challenge->name); ?></td>
                          <td class="td-actions text-right">

                            <table>
                              <tr>
                                <th>
                                  <form action="<?php echo e(route('challenge.detail', $challenge->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-success btn-link"><i
                                        class="material-icons">details</i></button>
                                  </form>
                                </th>

                                <th>
                                  <?php if(session()->get("level") === 1): ?>
                                  <form action="<?php echo e(route('challenge.destroy', $challenge->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-success btn-link"><i
                                        class="material-icons">delete</i></button>
                                  </form>
                                  <?php endif; ?>
                                </th>
                              </tr>
                            </table>
                          </td>
                        </tbody>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>




            </div>
          </div>
          <!--   Core JS Files   -->
          
  </body>
</html><?php /**PATH D:\XAMPP\htdocs\Class_Room\resources\views/challenge/index.blade.php ENDPATH**/ ?>